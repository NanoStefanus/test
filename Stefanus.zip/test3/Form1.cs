﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace test3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private String Hitung()
        {
            int input = Convert.ToInt32(txt1.Text);
            
            StringBuilder result = new StringBuilder();
            for (int i = 1; i < input; i++)
            {
                if (i % 3 == 0)
                {
                    result.Append("X");
                }
                else if(i % 5 == 0)
                {
                    result.Append("Y");
                }
                else if(i % 7 == 0)
                {
                    result.Append("Z");
                }
                else if (i % 3 == 0 && i % 5 == 0)
                {
                    result.Append("XY");
                }
                else if (i % 3 == 0 && i % 7 == 0)
                {
                    result.Append("XZ");
                }
                else if (i % 5 == 0 && i % 7 == 0)
                {
                    result.Append("YZ");
                }
                else if (i % 3 == 0 && i % 5 == 0 && i % 7 == 0)
                {
                    result.Append("XYZ");
                }
                else
                {
                    result.Append(i);
                }
            }
            return result.ToString();
        }
        private void btn1_Click(object sender, EventArgs e)
        {
            lb1.Items.Add(Hitung());
        }

        private void Form1_Validating(object sender, CancelEventArgs e)
        {
            if(txt1.Text == "")
            {
                e.Cancel = true;
            }
            else if(Convert.ToInt16(txt1.Text) > 1000 && Convert.ToInt16(txt1.Text) < 1)
            {
                e.Cancel = true;
            }
        }
    }
}
