﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace test1
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }
        private const String Letters = "abcdefghijklmnopqrstuvwxyz";
        private readonly char[] Alphanumeric = (Letters + Letters.ToUpper() + "0123456789").ToCharArray();

        #region public string[] SplitByString(string testString, string split)
        public static string[] SplitByString(string testString, string split)
        {
            int offset = 0;
            int index = 0;
            int[] offsets = new int[testString.Length + 1];

            while (index < testString.Length)
            {
                int indexOf = testString.IndexOf(split, index);
                if (indexOf != -1)
                {
                    offsets[offset++] = indexOf;
                    index = (indexOf + split.Length);
                }
                else
                {
                    index = testString.Length;
                }
            }

            string[] final = new string[offset + 1];
            if (offset == 0)
            {
                final[0] = testString;
            }
            else
            {
                offset--;
                final[0] = testString.Substring(0, offsets[0]);
                for (int i = 0; i < offset; i++)
                {
                    final[i + 1] = testString.Substring(offsets[i] + split.Length, offsets[i + 1] - offsets[i] - split.Length);
                }
                final[offset + 1] = testString.Substring(offsets[offset] + split.Length);
            }
            return final;
        }
        #endregion

        private String generateRandomAlphanumeric()
        {
            string bln = DateTime.Today.ToString("MM");
            StringBuilder result = new StringBuilder();
            Random rn = new Random();
            for (int i = 0; i < 16; i++)
            {
                //result.Append(Alphanumeric[rn.Next(Alphanumeric.Length)]);
                string test = Convert.ToString((Alphanumeric[rn.Next(Alphanumeric.Length)]).ToString());
              result.Append(test);
            }
            return result.ToString();
        }
        private void btGenerate_Click(object sender, EventArgs e)
        {
            lbres.Items.Add(generateRandomAlphanumeric());
        }
    }
}
